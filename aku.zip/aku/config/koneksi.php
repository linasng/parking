<?php
$host = 'localhost';
$user = 'root';
$password = '';
$database = 'db_parkir';

$con = new mysqli($host, $user, $password, $database);

if ($con->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>
